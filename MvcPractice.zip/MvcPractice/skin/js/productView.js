
function myPostData() {
    document.getElementById("addcart").submit();
} 
