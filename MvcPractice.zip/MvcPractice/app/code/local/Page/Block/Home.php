<?php
class Page_Block_Home extends Core_Block_Template
{
    public function __contruct()
    {
        $this->setTemplate('page/admin/home.phtml');
    }
}


?>