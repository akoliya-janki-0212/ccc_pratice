<?php

class Page_Block_Admin_Left extends Admin_Block_Layout
{
    public function __construct()
    {
        $this->setTemplate('page/admin/left.phtml');
    }
}