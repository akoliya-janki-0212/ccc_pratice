<?php
class Page_Block_Admin_Home extends Admin_Block_Layout
{
    public function __construct()
    {
        $this->setTemplate('page/admin/home.phtml');

    }
}


?>