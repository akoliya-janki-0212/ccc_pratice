<?php
class Page_Block_Footer extends Core_Block_Layout
{
    public function __construct()
    {
        $this->setTemplate('page/footer.phtml');
    }
}
?>