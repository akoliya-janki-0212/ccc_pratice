<?php
class Core_Model_Db_Table
{


}

?>