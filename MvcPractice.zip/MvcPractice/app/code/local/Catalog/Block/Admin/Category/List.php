<?php
class Catalog_Block_Admin_Category_List extends Admin_Block_Layout
{
    public function __construct()
    {
        $this->setTemplate('catalog/admin/category/list.phtml');
    }

}
?>