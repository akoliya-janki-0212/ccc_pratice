<?php
class Catalog_Block_Admin_Product_list extends Admin_Block_Layout
{
    public function __construct()
    {
        $this->setTemplate('catalog/admin/product/list.phtml');
    }

}
?>