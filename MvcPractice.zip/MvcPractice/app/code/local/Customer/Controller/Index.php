<?php
class Customer_Controller_Index
{
    public function index()
    {
        echo dirname(__FILE__);

    }
    public function new()
    {
        echo dirname(__FILE__);

    }
    public function list()
    {
        echo dirname(__FILE__);

    }
    public function save()
    {
        echo dirname(__FILE__);

    }
    public function delete()
    {
        echo dirname(__FILE__);

    }
}
?>