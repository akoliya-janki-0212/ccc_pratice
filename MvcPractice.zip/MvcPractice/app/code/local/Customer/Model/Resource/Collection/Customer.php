<?php
class Customer_Model_Resource_Collection_Customer extends Core_Model_Resource_Collection_Abstract
{

}
?>