<?php
class Customer_Model_Resource_Collection_Address extends Core_Model_Resource_Collection_Abstract
{

}
?>