<?php
class Cart_Model_Resource_Collection_Cart extends Core_Model_Resource_Collection_Abstract
{

}

?>