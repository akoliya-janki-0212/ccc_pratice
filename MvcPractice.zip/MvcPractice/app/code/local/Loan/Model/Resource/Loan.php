<?php
class Loan_Model_Resource_Loan extends Core_Model_Resource_Abstract
{
    public function __construct()
    {
        $this->init('ccc_load_calculator', 'id');
    }
}
?>