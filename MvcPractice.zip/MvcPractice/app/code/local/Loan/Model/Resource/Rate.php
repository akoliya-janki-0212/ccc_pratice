<?php
class Loan_Model_Resource_Rate extends Core_Model_Resource_Abstract
{
    public function __construct()
    {
        $this->init('ccc_bank_rate', 'id');
    }
}
?>