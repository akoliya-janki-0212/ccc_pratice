<?php
class Loan_Model_Resource_Collection_Loan extends Core_Model_Resource_Collection_Abstract
{

}

?>