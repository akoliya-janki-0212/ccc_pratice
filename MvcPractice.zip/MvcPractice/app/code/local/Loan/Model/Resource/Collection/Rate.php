<?php
class Loan_Model_Resource_Collection_Rate extends Core_Model_Resource_Collection_Abstract
{

}

?>