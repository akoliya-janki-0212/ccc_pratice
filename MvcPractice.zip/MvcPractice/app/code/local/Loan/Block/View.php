<?php
class Loan_Block_View extends Core_Block_Template
{
    public function __construct()
    {
        $this->setTemplate('loan/view.phtml');
    }

}
?>