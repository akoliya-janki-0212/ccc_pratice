<?php
class Admin_Block_Login extends Admin_Block_Layout
{
    public function __construct()
    {
        $this->setTemplate('admin/login.phtml');
    }
}
?>