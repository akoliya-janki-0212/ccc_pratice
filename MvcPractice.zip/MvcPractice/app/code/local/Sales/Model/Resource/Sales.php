<?php
class Sales_Model_Resource_Sales
{

}
?>