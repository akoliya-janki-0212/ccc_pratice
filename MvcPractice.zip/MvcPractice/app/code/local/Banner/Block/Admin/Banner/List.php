<?php
class Banner_Block_Admin_Banner_List extends Admin_Block_Layout
{
    public function __construct()
    {
        $this->setTemplate('banner/admin/list.phtml');
    }
}
?>