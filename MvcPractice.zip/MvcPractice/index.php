<?php
include 'app/Mage.php';
include 'app/code/Local/autoload.php';

Mage::init();
?>